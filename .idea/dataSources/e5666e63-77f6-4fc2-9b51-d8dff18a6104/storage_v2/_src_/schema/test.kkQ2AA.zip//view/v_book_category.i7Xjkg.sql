create view v_book_category as
select `b`.`book_id`       AS `book_id`,
       `b`.`book_name`     AS `book_name`,
       `b`.`price`         AS `price`,
       `c`.`category_id`   AS `category_id`,
       `c`.`category_name` AS `category_name`
from ((`test`.`t_book_hb` `b` join `test`.`t_book_category_hb` `bc` on ((`b`.`book_id` = `bc`.`bid`)))
         join `test`.`t_category_hb` `c` on ((`bc`.`cid` = `c`.`category_id`)));

